/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package farmerprofitcalculations;

/**
 *
 * @author germi
 */
public class Crop {
    //state variables/Attributes - Represents the characteristics of objects
    private String cropName;
    private double cropValue;
    
    //getters - Retrieves the value of a state variable
    public String getCropName()
    {
        return this.cropName;
    }
    
    public double getCropValue()
    {
        return this.cropValue;
    }
    
    //setters - Sets or change the value of a state variable
    public void setCropName(String value)
    {
        this.cropName = value;
    }
    
    public void setCropValue(double value)
    {
        this.cropValue = value;
    }
    
    //no argument constructor - Makes an empty object
    public Crop(){}
    
    //full constructor - Makes a complete object
    public Crop(String cn, double cv)
    {
        this.cropName = cn;
        this.cropValue = cv;
    }
    
    //0verridden toString - This determines what is shown on the drop down interface
    public String toString()
    {
        return this.cropName;
    }
    
    
}
