/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package farmerprofitcalculations;

/**
 *
 * @author germi
 */
public class DataLoader {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
    //The method below gives an array of crops objects which contains all respective data
    public Crop[] loadData()
    {
        //Load crop names
        String cropNames[] = new String[6];
        cropNames[0] = "Select Crop";
        cropNames[1] = "Tomato";
        cropNames[2] = "Cucumber";
        cropNames[3] = "Pumpkin";
        cropNames[4] = "Eggplant";
        cropNames[5] = "Dragon Fruit";
        
        //Load crop values
        double cropValue[] = new double[6];
        cropValue[0] = 0;
        cropValue[1] = 15.95;
        cropValue[2] = 7.87;
        cropValue[3] = 5.75;
        cropValue[4] = 6.50;
        cropValue[5] = 45.25;
        
        //Array of crops 
        Crop cropList[] = new Crop[6];
        //Loop that creates all crop objects and adds them to the array
        for(int i=0; i<cropNames.length; i++)
        {
            //Makes the crop object
            Crop c1 = new Crop(cropNames[i], cropValue[i]);
            //Adds object to the array
            cropList[i] = c1;
        }
        return cropList;
    }
    
}
